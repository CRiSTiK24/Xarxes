/**************************************************************************/
/*                                                                        */
/* P1 - UEB amb sockets TCP/IP - Part I                                   */
/* Fitxer aUEB.c que implementa la capa d'aplicació de UEB, sobre la      */
/* cap de transport TCP (fent crides a la "nova" interfície de la         */
/* capa TCP o "nova" interfície de sockets TCP), en la part servidora.    */
/*                                                                        */
/* Autors: Cristian Bezerdic Stoica, Guillem Díaz Cabanas                 */
/* Data: 08/11/2022                                                       */
/*                                                                        */
/**************************************************************************/

/* Inclusió de llibreries, p.e. #include <sys/types.h> o #include "meu.h" */
/*  (si les funcions externes es cridessin entre elles, faria falta fer   */
/*   un #include del propi fitxer capçalera)                              */

#include "UEBp1-tTCP.h"
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h> 
#include "UEBp1-aUEBs.h"

/* Definició de constants, p.e.,                                          */

/* #define XYZ       1500                                                 */

/* Declaració de funcions INTERNES que es fan servir en aquest fitxer     */
/* (les  definicions d'aquestes funcions es troben més avall) per així    */
/* fer-les conegudes des d'aquí fins al final d'aquest fitxer, p.e.,      */

/* int FuncioInterna(arg1, arg2...);                                      */

int ConstiEnvMis(int SckCon, const char *tipus, const char *info1, int long1);
int RepiDesconstMis(int SckCon, char *tipus, char *info1, int *long1);

/* Definició de funcions EXTERNES, és a dir, d'aquelles que es cridaran   */
/* des d'altres fitxers, p.e., int UEBs_FuncioExterna(arg1, arg2...) { }  */
/* En termes de capes de l'aplicació, aquest conjunt de funcions externes */
/* formen la interfície de la capa UEB, en la part servidora.             */

/* Inicia el S UEB: crea un nou socket TCP "servidor" a una @IP local     */
/* qualsevol i al #port TCP “portTCPser”. Escriu l'identificador del      */
/* socket creat a "SckEsc".                                               */
/* Escriu un missatge que descriu el resultat de la funció a "MisRes".    */
/*                                                                        */
/* "MisRes" és un "string" de C (vector de chars imprimibles acabat en    */
/* '\0') d'una longitud màxima de 200 chars (incloent '\0').              */
/*                                                                        */
/* Retorna:                                                               */
/*  0 si tot va bé;                                                       */
/* -1 si hi ha un error en la interfície de sockets.                      */
int UEBs_IniciaServ(PaquetUEB *paquet)
{

    int *SckEsc = &paquet->SckEsc;
    int portTCPser = paquet->portTCPser;
    char *MisRes = paquet->missatgeError;

    int retornada = 0;

    const char IPloc[16] = "0.0.0.0\0";
    if(portTCPser == 0) 
	{
		portTCPser = 3000;
	}	
	*SckEsc = TCP_CreaSockServidor(IPloc, portTCPser);
    if(*SckEsc == -1) 
	{
        char tmp[200] = "ERROR: El socket ip no s'ha pogut crear\0";
        strcpy(MisRes,tmp);
        MisRes[199] = '\0';
        retornada = -1;
    }
    else 
	{
        char tmp[200] = "EXIT: El socket s'ha pogut crear\0";
        strcpy(MisRes,tmp);
        MisRes[199] = '\0';
    }
    paquet->portTCPser = portTCPser;
    return retornada;
}

/* Accepta una connexió d'un C UEB que arriba a través del socket TCP     */
/* "servidor" d'identificador "SckEsc". Escriu l'@IP i el #port TCP del   */
/* socket TCP "client" a "IPcli" i "portTCPcli", respectivament, i l'@IP  */
/* i el #port TCP del socket TCP "servidor" a "IPser" i "portTCPser",     */
/* respectivament.                                                        */
/* Escriu un missatge que descriu el resultat de la funció a "MisRes".    */
/*                                                                        */
/* "IPser" i "IPcli" són "strings" de C (vector de chars imprimibles      */
/* acabats en '\0') d'una longitud màxima de 16 chars (incloent '\0').    */
/* "MisRes" és un "string" de C (vector de chars imprimibles acabat en    */
/* '\0') d'una longitud màxima de 200 chars (incloent '\0').              */
/*                                                                        */
/* Retorna:                                                               */
/*  l'identificador del socket TCP connectat si tot va bé;                */
/* -1 si hi ha un error a la interfície de sockets.                       */
int UEBs_AcceptaConnexio(PaquetUEB *paquet)
{
    int SckEsc = paquet->SckEsc; 
    char *IPser = paquet->IPser;
    int *portTCPser = &paquet->portTCPser;
    char *IPcli = paquet->IPcli;				 
    int *portTCPcli = &paquet->portTCPcli;
    char *MisRes = paquet->missatgeError;


    int retornada;
    if((retornada = TCP_AcceptaConnexio(SckEsc, IPcli, portTCPcli)) == -1)
    {
        char tmp[200] = "ERROR: No s'ha pogut acceptar la conexio "
                        "entre el Socket local amb IP remota\0";
        strcpy(MisRes,tmp);
        MisRes[199] = '\0';
        retornada = -1;
    }
    else {
        char tmp[200] = "EXIT: S'ha pogut acceptar la conexio "
                        "entre el Socket local amb Ip remota\0";
        strcpy(MisRes,tmp);
        MisRes[199] = '\0';

        if (TCP_TrobaAdrSockLoc(SckEsc, IPser, portTCPser) == -1) {
            char tmp[200] = "ERROR: No s'ha treure les ip i ports del socket\0";
            strcpy(MisRes,tmp);
            MisRes[199] = '\0';
            retornada = -1;
        }
    }

    paquet->SckEsc = SckEsc;
    return retornada;
}

/* Serveix una petició UEB d'un C a través de la connexió TCP             */
/* d'identificador "SckCon". A "TipusPeticio" hi escriu el tipus de       */
/* petició (p.e., OBT) i a "NomFitx" el nom del fitxer de la petició.     */
/* Escriu un missatge que descriu el resultat de la funció a "MisRes".    */
/*                                                                        */
/* "TipusPeticio" és un "string" de C (vector de chars imprimibles acabat */
/* en '\0') d'una longitud de 4 chars (incloent '\0').                    */
/* "NomFitx" és un "string" de C (vector de chars imprimibles acabat en   */
/* '\0') d'una longitud <= 10000 chars (incloent '\0').                   */
/* "MisRes" és un "string" de C (vector de chars imprimibles acabat en    */
/* '\0') d'una longitud màxima de 200 chars (incloent '\0').              */
/*                                                                        */
/* Retorna:                                                               */
/*  0 si el fitxer existeix al servidor;                                  */
/*  1 la petició és ERRònia (p.e., el fitxer no existeix);                */
/* -1 si hi ha un error a la interfície de sockets;                       */
/* -2 si protocol és incorrecte (longitud camps, tipus de peticio, etc.); */
/* -3 si l'altra part tanca la connexió;                                  */
/* -4 si hi ha problemes amb el fitxer de la petició (p.e., nomfitxer no  */
/*  comença per /, fitxer no es pot llegir, fitxer massa gran, etc.).     */
int UEBs_ServeixPeticio(PaquetUEB *paquet)
{
    int SckCon = paquet->SckCon;
    char *TipusPeticio = paquet->tipusPeticio;
    char *NomFitx = paquet->NomFitx;
    char *arrelUEB = paquet->arrelUEB;
    char *MisRes = paquet->missatgeError;



    char path[10000];
    int retornada = 0;
    int tamanyFitxer;

    int err = RepiDesconstMis(SckCon, TipusPeticio, NomFitx, &tamanyFitxer);

    if(err == -1) 
	{
        char tmp[200] = "ERROR: Interficie socket ha retornat -1\n\0";
        strcpy(MisRes,tmp);
        MisRes[199] = '\0';
        retornada = -1;
    }
    else if(err == -2) 
	{
        char tmp[200] = "ERROR: El tipus de peticio no es correcte o "
					 "el tamany del fitxer no es correcte\0";
        strcpy(MisRes,tmp);
        MisRes[199] = '\0';
        retornada = -2;
    }
    else if(err == -3) 
	{
        char tmp[200] = "Client ha tancat socket\n\0";
        strcpy(MisRes,tmp);
        MisRes[199] = '\0';
        retornada = -2;
    }
    else if(NomFitx[0] != '/') 
	{
        char tmp[200] = "ERROR: El nom del fitxer ha de començar per \0";
        retornada = -4;
    }
    else 
	{
        if(strcmp(arrelUEB,"NULL")==0){
        int llargadaPath = strlen(getcwd(NULL, 0));

        

        memcpy(path, getcwd(NULL, 0), llargadaPath);

        memcpy(path + llargadaPath, NomFitx, tamanyFitxer);
        path[llargadaPath+tamanyFitxer] = '\0';
        }
        else{
            int llargadaPath = strlen(arrelUEB);

            memcpy(path, arrelUEB, llargadaPath);

            memcpy(path + llargadaPath, NomFitx, tamanyFitxer);
            path[llargadaPath+tamanyFitxer] = '\0';
        }
        struct stat informacioFitxer;
        if (stat(path, &informacioFitxer) == -1) 
		{
            char tmp[200] = "ERROR: El fitxer no existeix\0";
            strcpy(MisRes,tmp);
            MisRes[199] = '\0';
            retornada =  1;
        }
        else if(informacioFitxer.st_size > 9999) 
		{
            char tmp[200] = "ERROR: El fitxer es massa gran\0";
            strcpy(MisRes,tmp);
            MisRes[199] = '\0';
            retornada = -4;
        }
        else if(informacioFitxer.st_size == 0) 
		{
            char tmp[200] = "ERROR: El fitxer esta buit\0";
            strcpy(MisRes,tmp);
            MisRes[199] = '\0';
            retornada =  -4;
        }
        else {
            int fdArchiu = open(path, O_RDONLY);
            if(fdArchiu == -1) {
                retornada = -4;
                char tmp[200] = "ERROR: No s'ha pogut obrir el fitxer: \0";
                strcpy(MisRes,tmp);
                MisRes[199] = '\0';
            }
            char bufferArchiu[9999];
            if(read(fdArchiu, bufferArchiu, 9999) == -1) 
			{
                retornada = -4;
                char tmp[200] = "ERROR: No s'ha pogut llegir el fitxer\0";
                strcpy(MisRes,tmp);
                MisRes[199] = '\0';
            }
            else 
			{
                int enviament = ConstiEnvMis(SckCon, "COR\0", bufferArchiu, informacioFitxer.st_size);
                if(enviament == -1) 
				{
                    char tmp[200] = "ERROR: a la interficie de sockets\0";
                    strcpy(MisRes,tmp);
                    MisRes[199] = '\0';
                    retornada = -1;
                }
                else 
				{
                    char tmp[200] = "EXIT: S'ha enviat el missatge \0";
                    strcpy(MisRes,tmp);
                    MisRes[199] = '\0';
                }
            }

        }
    }

    paquet->SckCon = SckCon;
    return retornada;

}

/* Tanca la connexió TCP d'identificador "SckCon".                        */
/* Escriu un missatge que descriu el resultat de la funció a "MisRes".    */
/*                                                                        */
/* "MisRes" és un "string" de C (vector de chars imprimibles acabat en    */
/* '\0') d'una longitud màxima de 200 chars (incloent '\0').              */
/*                                                                        */
/* Retorna:                                                               */
/*   0 si tot va bé;                                                      */
/*  -1 si hi ha un error a la interfície de sockets.                      */
int UEBs_TancaConnexio(PaquetUEB *paquet)
{
    int SckCon = paquet->SckCon;
    char *MisRes = paquet->missatgeError;

    int retornada = 0;
    if(TCP_TancaSock(SckCon) == -1) 
	{
        retornada = -1;
        char tmp[200] = "ERROR: No s'ha pogut tancar el fitxer\0";
        strcpy(MisRes,tmp);
        MisRes[199] = '\0';
    }
    else 
	{
        char tmp[200] = "EXIT: S'ha pogut tancar el fitxer\0";
        strcpy(MisRes,tmp);
        MisRes[199] = '\0';
    }
    return retornada;
}

/* Si ho creieu convenient, feu altres funcions EXTERNES                  */

/* Descripció de la funció, dels arguments, valors de retorn, etc.        */
/* int UEBs_FuncioExterna(arg1, arg2...)
{
	
} */

/* Definició de funcions INTERNES, és a dir, d'aquelles que es faran      */
/* servir només en aquest mateix fitxer. Les seves declaracions es        */
/* troben a l'inici d'aquest fitxer.                                      */

/* Descripció de la funció, dels arguments, valors de retorn, etc.        */
/* int FuncioInterna(arg1, arg2...)
{
	
} */

/* Accedeix a la configuració del servidor localitzada a ser                     */
/*                                                                        */
/* Si la troba, llavors llegeix el fitxer i guarda el contingut de la primera linea
a la array de chars "ArrelUEB". Comprova despres que la primera linea de aquesta
tingui la paraula clau "Arrel" al principi*/
/* arrelUEB és una string amb capacitat per 10000 caractes, mentre que misres
n'es altre amb capacitat per 200*/
/*                                                                        */
/* Retorna:                                                               */
/*  0 si tot va bé;                                                       */
/* -1 si no s'ha pogut llegir el fitxer;                       */
/* -2 si protocol és incorrecte (longitud camps, tipus de peticio).       */
int UEBs_ConfiguracioServer(PaquetUEB *paquet){

    char *arrelUEB = paquet->arrelUEB;
    char *MisRes = paquet->missatgeError;

    int llargadaPath = strlen(getcwd(NULL, 0));
    char path[10000];
    memcpy(path, getcwd(NULL, 0), llargadaPath);
    memcpy(path + llargadaPath, "/ser.cfg", 8);
    path[llargadaPath+8] = '\0';

    int retornada = 0;
    FILE *fp;

    fp = fopen(path, "r"); // open the file in read mode
    if (fp == NULL) {
        printf("%s", path);
        retornada = -1;
        char tmp[200] = "ERROR: No s'ha pogut obrir el fitxer de configuracio\0";
        strcpy(MisRes,tmp);
        MisRes[199] = '\0';
    }
    else{
        if(fgets(arrelUEB, 10000, fp) == NULL) { //copiem els 6 primers caractes de fp a arrelUEB, per tant, sobreescrivim la arrel
        retornada = -1;
        char tmp[200] = "ERROR: Al llegir de la configuracio del servidor\0";
        strcpy(MisRes,tmp);
        MisRes[199] = '\0';
        }
        else{
            char principi[6];
            memcpy(principi,arrelUEB,6);
            principi[5] = '\0';
            if(strcmp(principi,"Arrel")==0){
                char tmp[200] = "EXIT: Al aconseguir arrel\0";
                strcpy(MisRes,tmp);
                MisRes[199] = '\0';
            }
            else{
                printf("%s\n",principi);
                retornada = -2;
                char tmp[200] = "ERROR: La primera linea no és \"Arrel\"\0";
                strcpy(MisRes,tmp);
                MisRes[199] = '\0';
            }
            fclose(fp); // close the file
        }
    }
    return retornada;
}
/* "Construeix" un missatge de PUEB a partir dels seus camps tipus,       */
/* long1 i info1, escrits, respectivament a "tipus", "long1" i "info1"    */
/* (que té una longitud de "long1" bytes), i l'envia a través del         */
/* socket TCP “connectat” d’identificador “SckCon”.                       */
/*                                                                        */
/* "tipus" és un "string" de C (vector de chars imprimibles acabat en     */
/* '\0') d'una longitud de 4 chars (incloent '\0').                       */
/* "info1" és un vector de chars (bytes) qualsevol (recordeu que en C,    */
/* un char és un enter de 8 bits) d'una longitud <= 9999 bytes.           */
/*                                                                        */
/* Retorna:                                                               */
/*  0 si tot va bé;                                                       */
/* -1 si hi ha un error a la interfície de sockets;                       */
/* -2 si protocol és incorrecte (longitud camps, tipus de peticio).       */
int ConstiEnvMis(int SckCon, const char *tipus, const char *info1, int long1)
{
    int retornada = 0;
	char buffer[17+long1];
    memcpy(buffer, tipus, 3);
    char charLong[4];
    sprintf(charLong,"%.4d",long1);
    //charLong[4] = "\0"; //TODO: 222:17 makes integer from pointer without a cast
    memcpy(buffer+3, charLong, 4);
    memcpy(buffer+7, info1, long1);
    if(TCP_Envia(SckCon, buffer, 7 + long1) == -1) 
	{
        retornada = -1;
    }
    return retornada;
}

/* Rep a través del socket TCP “connectat” d’identificador “SckCon” un    */
/* missatge de PUEB i el "desconstrueix", és a dir, obté els seus camps   */
/* tipus, long1 i info1, que escriu, respectivament a "tipus", "long1"    */
/* i "info1" (que té una longitud de "long1" bytes).                      */
/*                                                                        */
/* "tipus" és un "string" de C (vector de chars imprimibles acabat en     */
/* '\0') d'una longitud de 4 chars (incloent '\0').                       */
/* "info1" és un vector de chars (bytes) qualsevol (recordeu que en C,    */
/* un char és un enter de 8 bits) d'una longitud <= 9999 bytes.           */
/*                                                                        */
/* Retorna:                                                               */
/*  0 si tot va bé,                                                       */
/* -1 si hi ha un error a la interfície de sockets;                       */
/* -2 si protocol és incorrecte (longitud camps, tipus de peticio);       */
/* -3 si l'altra part tanca la connexió.                                  */
int RepiDesconstMis(int SckCon, char *tipus, char *info1, int *long1)
{
    int retornada = 0;
	char buffer[10006];
    // Llegeix el missatge del socket
	//!TODO mirar si TCP_Rep ha llegit menys de 7 bytes i per tant hi ha perrill de segfault

    int read = TCP_Rep(SckCon, buffer, 10006);

    if(read == -1) 
	{
        retornada = -1;
    }
    else if(read == 0){
        retornada = -3;
    }
    else 
	{
		/* Guarda a tipus una substring del buffer del char 0 al 2 		  */
        memcpy(tipus, buffer, 3);
        tipus[3] = '\0';

        if(strcmp(tipus,"OBT")!=0)
		{
            retornada = -2;
        }
        else 
		{
			/* Guarda en una nova string tamanyFitxer una substring del   */
			/* char 3 al 7 del buffer								      */
            char tamanyFitxer[4];
            memcpy(tamanyFitxer, buffer+3, 4);

			/* Converteix tamanyFitxer a un enter 						  */
            *long1 = atoi(tamanyFitxer);
            /* Llegeix els caràcters de tamanyFitxer del buffer i els 	  */
			/* guarda a NomFitx 										  */

            memcpy(info1, buffer+7, *long1);


        }
    }
    return retornada;

}

/* Examina simultàniament i sense límit de temps (una espera indefinida)  */
/* els sockets (poden ser TCP, UDP i  teclat -stdin-) amb identificadors  */
/* en la llista “LlistaSck” (de longitud “LongLlistaSck” sockets) per     */
/* saber si hi ha arribat alguna cosa per ser llegida, excepte aquells    */
/* que tinguin identificadors igual a -1.                                 */
/* Escriu un text que descriu el resultat de la funció a "TextRes".       */
/*                                                                        */
/* "LlistaSck" és un vector d'int d'una longitud d'almenys LongLlistaSck. */
/* "TextRes" és un "string" de C (vector de chars imprimibles acabat en   */
/* '\0') d'una longitud màxima de 200 chars (incloent '\0').              */
/*                                                                        */
/* Retorna:                                                               */
/*  l'identificador del socket a través del qual ha arribat alguna cosa;  */
/*  -1 si hi ha error.                                                    */
int UEBs_HaArribatAlgunaCosa(PaquetUEB *paquet)
{

    const int *LlistaSck = paquet->LlistaSck; 
    int LongLlistaSck = paquet->LongLlistaSck;
    char *TextRes = paquet->missatgeError;

    int retornada = 0;
	retornada = TCP_HaArribatAlgunaCosaEnTemps(LlistaSck, LongLlistaSck, -1);
    if(retornada == -1)
	{
		char tmp[200] = " \0";
        strncpy(TextRes, tmp, strlen(tmp));
        TextRes[sizeof TextRes - 1] = '\0';
	}
	char tmp[200] = " \0";
    strncpy(TextRes, tmp, strlen(tmp));
    TextRes[sizeof TextRes - 1] = '\0';
	return retornada;
}
