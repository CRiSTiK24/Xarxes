gcc UEBp1-aUEBs.c UEBp1-ser.c UEBp1-tTCP.c -o server
